# jaro_tooth

## 🟢 Starten van de AI-dashboard CLI

Om het AI-controlecentrum van JARO-TOOTH te starten, gebruik je het volgende script:

```bash
python interface/dashboard_cli.py
```
